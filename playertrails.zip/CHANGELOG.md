v1.0.1:
- Fixed: Non-admins getting trails if admin only was set to 1.
- Changed: Version name and autoexec name.

v1.0.0:
- Initial Public Release